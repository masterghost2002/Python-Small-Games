Hello This is A simple Python Game
Consisting 2 games.....
Guessing Number And Stone Paper Scissor
Rules for Stone Paper Scissor
  there will be 10 life
   Read The Table Below To Understand The Winning Point
 

  Player                PC              POINT
  Stone(s)           Paper(P)         +1 Point to player
  Paper(p)           Stone(s)         +1 Point to computer
  Paper(p)           Scissor(c)       +1 Point to computer
  Scissor(c)         Paper(p)         +1 point to player
  Stone(s)           Scissor(c)       +1 Point to player
  Scissor(c)         Stone(c)         +1 Point to computer

                Same Guess(case)           Tie

2. Guessing Number

You Have to guess a number between 0-40
you will given 6 chances




You Can Aslo Randomise guessing number 
######################## Rakesh Dhariwal #####################